import java.util.Scanner;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Library library = new Library();

        while (true) {
            System.out.println("\n===== Library Menu =====");
            System.out.println("1. Add Book");
            System.out.println("2. Display Books");
            System.out.println("3. Issue Book");
            System.out.println("4. Return Book");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1 -> {
                    System.out.print("Enter title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter author: ");
                    String author = scanner.nextLine();
                    library.addBook(new Book(title, author));
                    System.out.println("Book added.");
                }
                case 2 -> library.displayBooks();
                case 3 -> {
                    System.out.print("Enter title to issue: ");
                    String title = scanner.nextLine();
                    library.issueBook(title);
                }
                case 4 -> {
                    System.out.print("Enter title to return: ");
                    String title = scanner.nextLine();
                    library.returnBook(title);
                }
                case 5 -> {
                    System.out.println("Exiting system.");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }
}

/*
Output Process:-
   
Microsoft Windows [Version 10.0.26100.4351]
(c) Microsoft Corporation. All rights reserved.

D:\ELEVATOR JAVA INTERNSHIP>javac *.java

D:\ELEVATOR JAVA INTERNSHIP>java LibraryManagementSystem

===== Library Menu =====
1. Add Book
2. Display Books
3. Issue Book
4. Return Book
5. Exit
Choose an option: 2
No books available.

===== Library Menu =====
1. Add Book
2. Display Books
3. Issue Book
4. Return Book
5. Exit
Choose an option: 1
Enter title: Java Book
Enter author: Hari Krishna
Book added.

===== Library Menu =====
1. Add Book
2. Display Books
3. Issue Book
4. Return Book
5. Exit
Choose an option: 1
Enter title: UI Full Stack Book
Enter author: Sudhakar Sharma
Book added.

===== Library Menu =====
1. Add Book
2. Display Books
3. Issue Book
4. Return Book
5. Exit
Choose an option: 1
Enter title: Oracle Book
Enter author: Sudhakar Tripathi
Book added.

===== Library Menu =====
1. Add Book
2. Display Books
3. Issue Book
4. Return Book
5. Exit
Choose an option: 1
Enter title: Selenium Book
Enter author: Suresh Panda
Book added.

===== Library Menu =====
1. Add Book
2. Display Books
3. Issue Book
4. Return Book
5. Exit
Choose an option: 1
Enter title: Python Book
Enter author: KV Roa
Book added.

===== Library Menu =====
1. Add Book
2. Display Books
3. Issue Book
4. Return Book
5. Exit
Choose an option: 2
Java Book by Hari Krishna [Available]
UI Full Stack Book by Sudhakar Sharma [Available]
Oracle Book by Sudhakar Tripathi [Available]
Selenium Book by Suresh Panda [Available]
Python Book by KV Roa [Available]

===== Library Menu =====
1. Add Book
2. Display Books
3. Issue Book
4. Return Book
5. Exit
Choose an option: 3
Enter title to issue: Python Book
Book issued successfully.

===== Library Menu =====
1. Add Book
2. Display Books
3. Issue Book
4. Return Book
5. Exit
Choose an option: 3
Enter title to issue: Java Book
Book issued successfully.

===== Library Menu =====
1. Add Book
2. Display Books
3. Issue Book
4. Return Book
5. Exit
Choose an option: 3
Enter title to issue: UI Full Stack Book
Book issued successfully.

===== Library Menu =====
1. Add Book
2. Display Books
3. Issue Book
4. Return Book
5. Exit
Choose an option: 4
Enter title to return: Python Book
Book returned successfully.

===== Library Menu =====
1. Add Book
2. Display Books
3. Issue Book
4. Return Book
5. Exit
Choose an option: 5
Exiting system.
*/
