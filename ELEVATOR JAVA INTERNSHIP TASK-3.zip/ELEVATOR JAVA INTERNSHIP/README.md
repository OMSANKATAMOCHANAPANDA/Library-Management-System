# Library Management System (Java)

## 📋 Description
This project is a command-line based Library Management System built using Java OOP principles. It allows the user to:
- Add new books
- View all books
- Issue a book
- Return a book

## 🛠 Technologies Used
- Java
- OOP Concepts: Abstraction, Inheritance, Polymorphism

## 🚀 How to Run
1. Compile all Java files:
   ```
   javac *.java
   ```
2. Run the main program:
   ```
   java LibraryManagementSystem
   ```

## 🧠 Key Concepts
- Book, User, and Library classes
- Book issue and return logic
- OOP features: Abstraction, encapsulation, and class relationships

## 👨‍💻 Author
[Your Name]
